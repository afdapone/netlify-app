import scrapper from './scrapper.js'


async function scrape() {
    return await scrapper()
}


export {
    scrape
}